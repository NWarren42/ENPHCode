Setting up on MacOS with command-line 'make'
--------------------------------------------

NOTE THAT THIS ASSIGNMENT ALSO NEEDS FFTW ON STEP 6 BELOW.

1. Open a terminal window.

2. Install Homebrew by executing this:

       /bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"

   This will take a while.  If errors occur during the installation,
   correct them and try again.  Only continue if you have a successful
   installation.

3. Execute: brew install gcc

4. Execute: xcode-select -install

5. Execute: brew install glfw

6. Execute: brew install fftw
